-- TU - Event REgistration
-- Author: Thalassicus
-- DateCreated: 4/5/2011 1:59:05 PM
--------------------------------------------------------------

include( "ThalsUtilities" )

Events.ActivePlayerTurnStart		.Add(OnTurnStart)
Events.ActivePlayerTurnEnd			.Add(OnTurnEnd)
Events.SerialEventUnitCreated		.Add(OnNewUnit)
Events.SerialEventCityDestroyed		.Add(OnCityDestroyed)
Events.SerialEventCityCaptured		.Add(OnCityDestroyed)
LuaEvents.BuildingConstructed		.Add(OnBuildingConstructed)
LuaEvents.BuildingDestroyed			.Add(OnBuildingDestroyed)
LuaEvents.ActivePlayerTurnEnd_Unit	.Add(RemoveNewUnitFlag)
LuaEvents.ActivePlayerTurnStart_Plot.Add(LuaEvents.CheckPlotBuildingsStatus)
LuaEvents.ActivePlayerTurnEnd_Plot	.Add(LuaEvents.CheckPlotBuildingsStatus)
Events.SerialEventHexCultureChanged	.Add(OnHexCultureChanged)