-- NotificationAddin
-- Author: Thalassicus
-- DateCreated: 2/8/2011 6:41:15 AM
--------------------------------------------------------------

LuaEvents.NotificationContextAddin( {context="BC_Notifications"} )
LuaEvents.NotificationAddin( { name = "Refugees", type = "CNOTIFICATION_REFUGEES" } )
LuaEvents.NotificationAddin( { name = "CSCapture", type = "CNOTIFICATION_CS_CAPTURE" } )
