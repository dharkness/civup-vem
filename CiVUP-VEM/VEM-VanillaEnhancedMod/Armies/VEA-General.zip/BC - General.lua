-- BC - General.lua
-- Author: Thalassicus
-- DateCreated: 10/29/2010 12:44:28 AM
--------------------------------------------------------------

--include( "LuaLogger.lua" );
--include( "CustomNotificationPanel.lua" );

--local logger = LuaLogger:New();
--logger:setLevel(LOG_DEBUG);

function doBalancePromotions()
	--logger:info("doBalancePromotions()");
	for playerID,pPlayer in pairs(Players) do
		if pPlayer and pPlayer:IsAlive() then
			for pUnit in pPlayer:Units() do
				if isGroundCombat(pUnit) then
					-- Automatic promotion swapping
					for row in GameInfo.PromotionSwap() do
						local type = GameInfo.Units[pUnit:GetUnitType()].Range > 0;
						checkReplacePromotion(pUnit, getPromotion(row, type), getPromotion(row, not type));
					end

					-- Manual promotion swapping
					pUnitClass = GameInfo.Units[pUnit:GetUnitType()].CombatClass;

					if pUnitClass == "UNITCOMBAT_ARMOR" then
						-- March and Repair functionally identical
						checkReplacePromotion(pUnit,
							GameInfo.UnitPromotions["PROMOTION_MARCH"].ID,
							GameInfo.UnitPromotions["PROMOTION_REPAIR"].ID
							);
					elseif pUnitClass == "UNITCOMBAT_HELICOPTER" then
						--[[
						In certain situations Helicopters with Blitz (upgraded from AT guns)
						can kill 7 units per turn. I've found this to be overpowered since Civ V
						armies are smaller than earlier civ games, easily wiping out a whole
						technologically inferior army with 1 unit's single turn. Logistics
						limits this to 2 kills per turn, a more reasonable figure.
						--]]
						checkReplacePromotion(pUnit,
							GameInfo.UnitPromotions["PROMOTION_BLITZ"].ID,
							GameInfo.UnitPromotions["PROMOTION_LOGISTICS"].ID
							);
					end
				end
			end
		end
	end
end

function isGroundCombat(pUnit)
	return pUnit and pUnit:IsCombatUnit() and pUnit:GetDomainType() == DomainTypes.DOMAIN_LAND;
end

function checkReplacePromotion(pUnit, oldPromo, newPromo)
	if pUnit:IsHasPromotion(oldPromo) then
		pUnit:SetHasPromotion(oldPromo, false);
		pUnit:SetHasPromotion(newPromo, true);
	end
end

function isTankWithMarch(pUnit)
	return ;
end

function getPromotion(row, type)
	return GameInfo.UnitPromotions[row[type and "Melee" or "Ranged"] ].ID;
end

Events.ActivePlayerTurnEnd.Add( doBalancePromotions );

---------------------------------------------------------------------
---------------------------------------------------------------------

function doCityCapture (hexPos, lostPlayerID, cityID, wonPlayerID)
	--logger:info("doCityCapture()");
	lostPlayer	= Players[lostPlayerID];
	wonPlayer	= Players[wonPlayerID];
    local pPlot	= Map.GetPlot( ToGridFromHex( hexPos.x, hexPos.y ) );
	if lostPlayer:GetNumCities() > 0 then
		-- Create partisans
		logger:debug("Partisans");
		local pCapitalCity = lostPlayer:GetCapitalCity();
		lostPlayer:InitUnit( getBestUnitType(lostPlayer), pCapitalCity:GetX(), pCapitalCity:GetY() );
		-- notification: "Guerrilla fighters from the city of <city> have fled to the nation's [ICON_CAPITAL] Capital!"
	elseif lostPlayer:IsMinorCiv() then
		local iTrait = lostPlayer:GetMinorCivTrait();
		logger:debug("Minor Civ Destroyed");
		logger:debug("Minor civ trait = " .. iTrait);
		
		if (iTrait == MinorCivTraitTypes.MINOR_CIV_TRAIT_MARITIME) then
			wonPlayer:GetCapitalCity():ChangePopulation(1);
			--[[LuaEvents.CustomNotification(1003,
										"City-State Captured",
										"Food looted from the Maritime [ICON_CITY_STATE] City-State of <city> allowed your [ICON_CAPITAL] Capital to grow by +1 [ICON_CITIZEN] Citizen.",
										{ location={pPlot:GetX(), pPlot:GetY()} }
										);--]]
		elseif (iTrait == MinorCivTraitTypes.MINOR_CIV_TRAIT_CULTURED) then
			wonPlayer:ChangeJONSCulture( 30 * wonPlayer:GetMinorCivCultureFriendshipBonus() );
			--"Cultural artifacts looted from the Cultural [ICON_CITY_STATE] City-State of <city> increased your empire's [ICON_CULTURE] Culture by <culture>."
		elseif (iTrait == MinorCivTraitTypes.MINOR_CIV_TRAIT_MILITARISTIC) then
			pUnit = getCombatUnitOnTile(hexPos);
			if pUnit then
				logger:debug("InitUnit(".. pUnit:GetUnitType() ..",".. pPlot:GetX() ..",".. pPlot:GetY() ..")" );
				wonPlayer:InitUnit( pUnit:GetUnitType(), pPlot:GetX(), pPlot:GetY() );
				-- "Your <unit> conscripted citizens from the Militaristic [ICON_CITY_STATE] City-State of <city> into your army."
			end
		end
	end
end

function getCombatUnitOnTile(hexPos)
    local pPlot = Map.GetPlot( ToGridFromHex( hexPos.x, hexPos.y ) );
	local count = pPlot:GetNumUnits();
	for i = 0, count - 1 do
		local pUnit = pPlot:GetUnit( i );
		if isGroundCombat(pUnit) then
			return pUnit;
		end
	end
	return nil;
end

function getBestUnitType(pPlayer)
	--logger:debug("getBestUnitType(" .. pPlayer:GetID() .. ")");
	local pCapitalCity = pPlayer:GetCapitalCity();
	local bestUnitType = nil;
	local bestCombatStrength = 1;
 	for unit in GameInfo.Units() do
		if pCapitalCity:CanTrain( unit.ID ) and unit.Combat > bestCombatStrength then
			logger:debug(" Possible best unit: "..unit.Type);
			local isResourceRequired = false;
			for unitType in GameInfo.Unit_ResourceQuantityRequirements() do
				if unitType.UnitType == unit then
					isResourceRequired = true;
					logger:debug("  requires resource");
					break;
				end
			end
			if not isResourceRequired then
				bestUnitType = unit.ID;
				bestCombatStrength = unit.Combat;
			end
		end
	end
	--logger:debug("Best unit: "..GameInfo.Units[bestUnitType].Type);
	return bestUnitType;
end

Events.SerialEventCityCaptured.Add( doCityCapture );