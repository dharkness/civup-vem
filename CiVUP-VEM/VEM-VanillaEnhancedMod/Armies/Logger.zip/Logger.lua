-- Event Logger
-- Author: Thalassicus
--------------------------------------------------------------

DEBUG = "DEBUG"
INFO = "INFO"
WARN = "WARN"
ERROR = "ERROR"
FATAL = "FATAL"

local LEVEL = {
	[DEBUG] = 1,
	[INFO]  = 2,
	[WARN]  = 3,
	[ERROR] = 4,
	[FATAL] = 5,
}

LoggerType = {};

function LoggerType:new()
	local logger = {};
	setmetatable(logger, self);
	self.__index = self;

	logger.level = LEVEL.DEBUG;

	logger.setLevel = function (self, level)
		self.level = level;
	end

	logger.log = function (self, level, message)
		if LEVEL[level] < LEVEL[self.level] then
			return false;
		end
		print(level .. ":  " .. message);
		return true;
	end

	logger.debug = function (logger, message) return logger:log(DEBUG, message) end
	logger.info  = function (logger, message) return logger:log(INFO,  message) end
	logger.warn  = function (logger, message) return logger:log(WARN,  message) end
	logger.error = function (logger, message) return logger:log(ERROR, message) end
	logger.fatal = function (logger, message) return logger:log(FATAL, message) end
	return logger;
end