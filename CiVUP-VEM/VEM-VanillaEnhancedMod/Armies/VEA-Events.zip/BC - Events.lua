-- BC - General.lua
-- Author: Thalassicus
-- DateCreated: 10/29/2010 12:44:28 AM
--------------------------------------------------------------

include( "CiVUP_General" );
include( "CustomNotification.lua" )

local logger = Game.LuaLogger:New();
logger:SetLevel(LOG_WARN);


LuaEvents.NotificationAddin( { name = "Refugees", type = "CNOTIFICATION_REFUGEES" } )
LuaEvents.NotificationAddin( { name = "CapturedMaritime", type = "CNOTIFICATION_CAPTURED_MARITIME" } )
LuaEvents.NotificationAddin( { name = "CapturedCultural", type = "CNOTIFICATION_CAPTURED_CULTURAL" } )
LuaEvents.NotificationAddin( { name = "CapturedMilitaristic", type = "CNOTIFICATION_CAPTURED_MILITARISTIC" } )

---------------------------------------------------------------------
---------------------------------------------------------------------

function doCityCapture (hexPos, lostPlayerID, cityID, wonPlayerID)
	logger:info("doCityCapture()");
	local wonPlayer		= Players[wonPlayerID];
	local capturingUnit = getCombatUnitOnTile(hexPos);
	local lostPlayer	= Players[lostPlayerID];
    local lostCityPlot	= Map.GetPlot( ToGridFromHex( hexPos.x, hexPos.y ) );
	local lostCity		= lostCityPlot:GetPlotCity();
	local lostCityName	= cityName(lostCity);
	local capitalCity	= lostPlayer:GetCapitalCity();
	local refugees		= false;
	
	if not (capturingUnit and capturingUnit:GetOwner() == wonPlayerID) then
		-- The new owner does not have a unit in the city.
		-- This occurs when cities are gifted.
		return;
	end

	if lostCity:GetPopulation() > 1 then
		lostCity:ChangePopulation(-1, true);
	end

	if capitalCity ~= nil then
		--logger:debug("Population");
		-- Population flees
		if lostCity:GetPopulation() > 1 then
			refugees = true;
			lostCity:ChangePopulation(-1, true);
			capitalCity:ChangePopulation(1, true);
			--[[
			local minCity = capitalCity;
			local minDistance = Map.PlotDistance(lostCity:GetX(), lostCity:GetY(), minCity:GetX(), minCity:GetY());
			local thisDistance = 0;
			for thisCity in lostPlayer:Cities() do
				thisDistance = Map.PlotDistance(lostCity:GetX(), lostCity:GetY(), thisCity:GetX(), thisCity:GetY());
				--print(cityName(thisCity) .. ": " .. thisDistance);
				if thisDistance < minDistance then
					minDistance = thisDistance;
					minCity = thisCity;
				end
			end
			--logger:debug(cityName(minCity));
			minCity:ChangePopulation(1);
			--]]
		end

		-- Create partisans
		logger:debug("Partisans");
		lostPlayer:InitUnit( getBestUnitType(lostPlayer), capitalCity:GetX(), capitalCity:GetY() );
		if lostCityPlot:IsRevealed(Game.GetActiveTeam()) then
			if refugees then
				CustomNotification(
					"Refugees",
					"Refugees flee "..lostCityName,
					"Refugees from "..lostCityName.." flee to "..capitalCity:GetName().." and rally as partisan fighters!",
					capitalCity:Plot(),
					0,
					"Red",
					0
				)
			else
				CustomNotification(
					"Partisans",
					"Partisans rally at "..capitalCity:GetName(),
					"Partisans from "..lostCityName.." rally at "..capitalCity:GetName().."!",
					capitalCity:Plot(),
					0,
					"Red",
					0
				)
			end
		end
	elseif lostPlayer:IsMinorCiv() then
		local iTrait = lostPlayer:GetMinorCivTrait();
		--logger:debug("Minor Civ Destroyed");
		--logger:debug("Minor civ trait = " .. iTrait);
		
		if (iTrait == MinorCivTraitTypes.MINOR_CIV_TRAIT_MARITIME) then
			local cityIDs = GetLargestCityIDs(wonPlayerID, true)
			local population = 4
			local popForCities = {}
			
			local cityIndex = 1
			for cityIndex = 1, GameInfo.UnofficialPatch["MARITIME_FOOD_CITIES"].Value do
				if cityIDs[cityIndex] ~= nil then
					table.insert(popForCities, 0)
				end
			end
			cityIndex = 1
			while population > 0 do
				popForCities[cityIndex] = popForCities[cityIndex] + 1
				population = population - 1
				cityIndex = cityIndex % #popForCities + 1
			end
			for cityIndex,v in pairs(popForCities) do
				wonPlayer:GetCityByID(cityIDs[cityIndex]):ChangePopulation(v,true)
			end
			if Game.GetActivePlayer() == wonPlayerID then
				CustomNotification(
					"CapturedMaritime",
					"Looted Food",
					"Food looted from the maritime [ICON_CITY_STATE] City-State of "..lostCityName.." caused a population boom in your five largest Cities.",
					lostCityPlot,
					0,
					0,
					0
				)
				--Events.GameplayAlertMessage("Food looted from [ICON_CITY_STATE] "..lostCityName.." grew your largest Cities!");
			end
		elseif (iTrait == MinorCivTraitTypes.MINOR_CIV_TRAIT_CULTURED) then
			local cultureLoot = 100 * wonPlayer:GetMinorCivCultureFriendshipBonus();
			wonPlayer:ChangeJONSCulture( cultureLoot );
			if Game.GetActivePlayer() == wonPlayerID then
				CustomNotification(
					"CapturedCultural",
					"Looted Cultural Artifacts",
					cultureLoot.." [ICON_CULTURE] Culture of priceless artifacts looted from the cultural [ICON_CITY_STATE] City-State of "..lostCityName..".",
					lostCityPlot,
					0,
					0,
					0
				)
				--Events.GameplayAlertMessage(cultureLoot.." [ICON_CULTURE] Culture looted from artifacts in [ICON_CITY_STATE] "..lostCityName..".");
			end
		elseif capturingUnit then
			local capturingUnitInfo = GameInfo.Units[capturingUnit:GetUnitType()]
			--print("InitUnit(".. capturingUnit:GetUnitType() ..",".. lostCityPlot:GetX() ..",".. lostCityPlot:GetY() ..")" );
			wonPlayer:InitUnit( capturingUnitInfo.ID, lostCityPlot:GetX(), lostCityPlot:GetY() );
			wonPlayer:InitUnit( capturingUnitInfo.ID, lostCityPlot:GetX(), lostCityPlot:GetY() );
			if Game.GetActivePlayer() == wonPlayerID then
				local capturingUnitIcon = {{"Unit1", capturingUnitInfo.ID, 0, 0, 0}}
				CustomNotification(
					"CapturedMilitaristic",
					"Conscripts",
					"Conscripted citizens into your army from the militaristic [ICON_CITY_STATE] City-State of "..lostCityName..".",
					lostCityPlot,
					0,
					0,
					capturingUnitIcon
				)
				--Events.GameplayAlertMessage("Conscripted citizens into your army from [ICON_CITY_STATE] "..lostCityName..".");
			end
		end
	end
end

function cityName(city)
	return Locale.ConvertTextKey(city:GetNameKey());
end

function getCombatUnitOnTile(hexPos)
    local lostCityPlot = Map.GetPlot( ToGridFromHex( hexPos.x, hexPos.y ) );
	local count = lostCityPlot:GetNumUnits();
	for i = 0, count - 1 do
		local pUnit = lostCityPlot:GetUnit( i );
		if IsDomainCombat(pUnit, "DOMAIN_LAND") then
			return pUnit;
		end
	end
	return nil;
end

function getBestUnitType(pPlayer)
	--logger:debug("getBestUnitType(" .. pPlayer:GetID() .. ")");
	local capitalCity = pPlayer:GetCapitalCity();
	local bestUnitType = GameInfo.Units["UNIT_WARRIOR"].ID;
	local bestCombatStrength = GameInfo.Units["UNIT_WARRIOR"].Combat;
 	for unit in GameInfo.Units() do
		if unit.Domain == "DOMAIN_LAND" and unit.Combat > bestCombatStrength and capitalCity:CanTrain( unit.ID ) then
			--logger:debug(" Possible best unit: "..unit.Type);
			local isResourceRequired = false;
			for unitType in GameInfo.Unit_ResourceQuantityRequirements() do
				if unitType.UnitType == unit.Type then
					isResourceRequired = true;
					--logger:debug("  requires resource");
					break;
				end
			end
			if not isResourceRequired then
				bestUnitType = unit.ID;
				bestCombatStrength = unit.Combat;
			end
		end
	end
	logger:debug("Best unit: "..GameInfo.Units[bestUnitType].Type);
	return bestUnitType;
end

Events.SerialEventCityCaptured.Add( doCityCapture );

logger:info("Loaded BC - Events.lua")